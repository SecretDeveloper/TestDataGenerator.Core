
TestDataGenerator
A library and command line tool that can be used to generate data for testing or other uses.  You provide it with a pattern containing symbols defining the output you want to produce and it will create random data to match that pattern.

 Quick Start with examples

 Installation
 There are a few ways you can intall tdg.
  - You can download the latest versions from the releases which will contain all you need to run the command line tdg tool.
  - You can install using Nuget by executing "nuget install tdg" in a terminal which will download and tdg and each of its required libraries to the current folder.
  - You can run "install-package tdg" from the Nuget Package Management Console to add TDG to your project.

 Placeholders
When using the commandline tool place all patterns and symbols inside '\\ ' tokens **without the backslash** e.g. 'Generate some Letters \\GC'. 

 Symbols
The pattern is as follows:
- `\.` - A single random upper-case, lower-case letter or number.
- `\W` - A single random upper-case or lower-case letter.
- `\w` - A single random upper-case or lower-case letter.
- `\L` - A single random upper-case Letter.
- `\l` - A single random lower-case letter.
- `\V` - A single random upper-case Vowel.
- `\v` - A single random lower-case vowel.
- `\C` - A single random upper-case Consonant.
- `\c` - A single random lower-case consonant.
- `\D` - A single random non number character.
- `\d` - A single random number, 1-9.
- `\s` - A whitespace character (Tab, New Line, Space, Carriage Return or Form Feed)
- `\n` - A newline character.
- `\t` - A tab character.

 Groups
- `(\d){5}` - Five digits between 0 and 9.
- `\L(\d){3}\L` - A upper-case letter, three digits between 0 and 9 and another upper-case letter.
- `(.[100-101]){3}` - Three items, each will include a dot '.' and either 100 or 101 e.g. *'.101.100.101'*

 Ranges
- `[a-z]` - A single lower-case letter between a and z.
- `[a-z]{5}` - Five lower-case letter between a and z.
- `[a-z]{5,10}` - Between five and ten lower-case letter between a and z.
- `[A-Z]` - A single upper-case letter between Z and Z.
- `[1-5]` - A number between 1 and 5.
- `[100-500]` - A number between 100 and 500.
- `[1-28]/[1-12]/[1960-2013]` - A date value between 1960 and 2013.
- `[1.00-5.00]` - A decimal number between 1.00 and 5.00.

 Alternations
**Alternatives must be contained within a Group**
- `(\L\L|\d\d)` - Either two upper-case letters OR two numbers.
- `(\L\L|\d\d|[AEIOU]|[100-120])` - Either two upper-case letters OR two digits OR an upper-case vowel OR a number between 100 and 120.

 Named Parameters
A named pattern is surrounded with @ characters and links to a predefined pattern loaded from a file. The `default.tdg-patterns` file located in the same directory as the tdg executable file contains a list of named patterns which can be used in other patterns you write.  For example to generate you could write something like `([1-9]\d\d-\d\d-\d\d\d\d)` or you can use the named parameter in the file `(@misc_ssn@)` to a similar value.  You can add more patterns to the file as you wish.  Named patterns can also include other named patterns if you so wish.  

Take a look at the `@address_us_type1@` pattern in the file as an example of a compound pattern than uses other patterns to produce an output.
'1 Creekside Boulevard, Forsyth County, Ohio, 62677'

 CommandLine tool
You can use the `tdg.exe` application to generate test data from the command line.  It can handle provided templates directly from the command line or from a file. The tool also supports exporting the generated output to either the command line or another file.

 Parameters:
- `-t, --template:`    The template containing 1 or more patterns to use when producing data.
- `-p  --pattern:`     The pattern to use when producing data.
- `-i  --inputfile:`   The path of the input file.
- `-o, --output:`      The path of the output file.
- `-c, --count:`       The number of items to produce.
- `-v, --verbose:`     Verbose output including debug and performance information.
- `--help`            Display the help screen.
  
 Examples
- Single repeating symbols using the following syntax
  - `tdg -t 'Letters \\YCEJUEUHVXOSSAZUWBNN and Numbers \\296346642351'`
  - Produces items like *'Letters JRKEYCZMQBDFCIOHZWUF and Numbers 114947914304'*.
- Repeating patterns containing multiple letters or numbers of random length.
  - `tdg -t '\\JKJAQ'` - Will generate 5 random upper-case characters. e.g. *'VWUCA'*
  - `tdg -t '\\XF8MH1DJ4JO3BE2LT1DW9IZ6WS9OR1AA1BH2CY4VZ1VS9BI2TE0RQ2AO2FQ6EP6IJ5EZ8BJ8'`  - Will generate 24 repeating letter-letter-number values e.g. *'SI8WM2TU3TU5CI3XB7YW3WQ4LN3JW3IR8GZ3JE0YM8FL7EG0DH9DC4NV6LL9YJ9BK1RV3BN8'*
- Variable length data can be generated also
  - `tdg -t '\\AJMQFQGHIFPJEPIT'` - Will generate a string containing between 10 and 20 characters of random value e.g. *'RYSEADXEARM'*
  - `tdg -t 'Letters \\QCUBNCDBE and Numbers \\8166136'` produces items like *'Letters NJCFKO and Numbers 402'*
- Input can contain several placeholders.
  - `tdg -t 'Hi there \\Pauwo Deofuao how are you doing?  Your SSN is \\495-47-1134.' -c 100` 
  - Produces 100 items like *'Hi there Rbcu Leutuipa how are you doing?  Your SSN is 422-46-9620.'*
- Generate 100 SSN like values and output to console window.
  - `tdg -t '\\476-52-4646' -c 100`
  - Produces 100 items like *'422-92-1749'*.
- Generate 100 strings with random name like values and output to file.
  - `tdg -t 'Hi there \\Cafa Zufmoecmi how are you doing?' -c 100 -o C:\test1.txt`
  - Produces 100 items like *'Loxa Ternuuzpo'*.
- `tdg -t '\\Letters Xqly and Numbers 1298
'` produces the following output: *'Letters IIGbZ and Numbers 15977691357
'*

 More Information

 Placeholders
You can place your symbols and patterns within placeholders which will be replaced with the generated values.  These placeholders contain 1 or more symbols representing the desired output characters.  Note that placeholders are wrapped in double angle brackets `\\PATTERN` without the backslash.
*Please note I am supplying a backslash at the start of all placeholder examples so that they appear as examples correctly.  You do not need to add these.*

 Pattern Composition
If you are familiar with Regular Expressions then most of the syntax used will be familiar but there are significant differences in place given that regex is used to match a string against a pattern.  The generator instead uses simple patterns opf symbols to produce strings, because of the difference in usage the syntaxes cannot match up entirely.  Patterns define what the generated values will be and can be composed using text and symbols.  Sections of the pattern can be repeated a specific number of times (they can also be repeated a random number of times by providing a min and max).  Patterns can also include alternate items that will be randomly selected, helping to produce relatively complicated outputs. 

`\\Meee` is a placeholder containing the pattern of symbols `\L\v\l\v`.

 Symbol Repetition
Individual symbols can be repeated by a supplying a repeat section immediately after the symbol.  
For example `\L{5}` will produce 5 upper case letters.  You can also add some randomness to the mix by supplying a range: `\L{min,max}`.  The pattern `\L{1,100}` will produce between 1 and 100 upper case letters. Here's one *'FUGENUWIINUTLCPRNZULRAJJICBRJVSSXDMVUVKJQPLGVGSHYDYG'*

 Symbol Grouping
Individual symbols can be grouped together using parenthesis characters.  When grouped together they can be repeated using the same repeat syntax.  
`(\l\d){5}` will produce something like *'j7v1k9v4s2'*.
You can also include the random range syntax from above.

 Alternating Symbols and Groups
Patterns can contain several individual symbols or groups of symbols and randomly alternate between them when generating the output value.  `\\Z|nwcwhrtxsq|IUA|aiaeoo` will produce either a single upper-case consonant, 10 lower-case consonants, 3 upper-case vowels or between 10 and 15 lower-case vowels.  Which one gets outputed is randomly selected when processing the pattern.

 Other patterns:
- `'\\This is a GW string'` will produce something similar to *'This is a LI string'*.
- `'\\This is a 1324809646947346222 string'` will produce something similar to *'This is a 6997623709476377933 string'*.
- Individual symbols can be repeated a specific number of times using the syntax `\L{10}` which will generate 10 upper case letters.
- Individual symbols can be repeated a random number of times using the syntax `\L{10,20}` which will generate between 10 and 20 upper case letters.
- 1 or more Symbols can be combined into patterns by wrapping them in parenthesis e.g. `(\*\L\d)`.
- Patterns can be repeated a specific number of times using the syntax `(\L\d){10}` which will generate 10 repeated letter-number pairs e.g. *'A6P8K4Q7U7Y1N0Q7K1O6'*.
- Patterns can be repeated a random number of times using the syntax `(\L\d){10,20}` which will generate between 10 and 20 repeated letter-number pairs e.g. *'M2X6Y9I0A6M3X2O0D5I9O5'*.

 Profiling results
*These timings are taken from unit tests making direct API calls, the command line tool will have higher times as it has additional IO work to output the values to screen or file.  Should still be fast.*
- 1000 instances of the following template generated in 172 milliseconds.
  - `\\A1WZ69QIOK6154SDLNHSUA47671625GSPYGVVYFJJRCCRT7130176870603989BZDYOPDXHNHYICXKCWCZIGLMASDGETOI44619711947657560295896856984875YZLXMULJRZZVMVZHELEXUBMPUUOHVIRCTFRNHQFHVPVWYUITSQRASUSWMWCSGEOI3802140528122660485166394803550604506062517865682024536651733697WLFTCPIKEHPOWNHZFFELHOBQVXNPGHXZDBZFIWTPTVGHUDUZVVCELOLHJOXFCSDXKQKUOBQIMORLHUVSCOULFSNPQRVTYONBRJWESZKTEUSWWZAPSFCNYSRSCVEXFXJX06799600102406766207400961088452388220601039426415298640572761264002844550546154457325473764884077442466063809432730394952807977PMSXSDFAYEGOFOSJJIFBOJUVHOVYPQVCYQGPHNRCOHCDSWSAOMQMTRDFSXQEHGKHIDPOIDCWQDMHHQCKWVKDZJJGNAWKWNUHXUVPGDSKKUVPEWYCUFIMWGIZTJBHGRZDJFJMUNDSDZSFNTBQCUPRFHLQMWVXBKESVSFZNLHGBPJWODLZHLELCIYCTSAYSGQSVZJVOCCRNJPPXOCJLVQQGTQNTDGVLINVYRBPTPLEINYTSIEEPQNXPAMBIWCKWHFE8762556834378884902786292928503027996960065177240648043157052733124098703171101477785598473981823104324194496104558494753561571225890715359109127842332834175261226130374213565333463889296663909788209646801827983289743793471131488603471708736878962904551527KSRALMXHTBTBVZKMZOSOZKDRYLUKBOFYNKJHETXFALBXYDDAZCNOUSTAPZCZRMGEVUNLQCHGQNNOIGTUITLYARDVQISEQYNOFXBDPSKXUHXHEFSJGHRYAHEERSVHKCPSZZJLEPEPINDTTWRKQJYJGPNXSWMXXDNSRFHEWGEQCBPMDKLUAKQAEGLKMMSHDGSFALCNOMOJEIGEAATILRXMMMOKTXSKOWMVJKLSIXGNWHWVAGKLSJWMJGSOXRUQUEVHVKVPOBANKJPFPSKMNGREAAMCRXUQDQTSLOAPLUXRJIBAQMZFGHDNNQHUYSYRGJKUPXUBSVBTJZURZLMFYOJWMFFVHFRSWGKZYGLSSXNLFKENVPVNGSTRAOHKSYTNDJWDOVTSZTNABXQCARZSJDLDMTZKZBZTEAIWNBZAVDNNFTQCXFJBZBDZXTQVVJTYTUVBPTPZSYWGQYYTCXMURYTCWIZULDEMJOTKXOMDPKJAFWJYUWSYWZHUASEHUUOOTJWC15854312579990954264294131388728027201558922813780157482161203484097275260627132850867054513035454772640488685493934361704275123517336920937937801019119206737426417816791332386737410340802928340142908531877692009001506790377299223473898946211091824953620815467746863621266948938637427084207358947413720378768298683032987942391709141581615821590966581553587808796914719241615634132421769700381703568524734083885376527415591886090216651778777581590518505302384899367861475873700039557260035948487812362803273159135NIMEDASTKRNJTJVPXYVQRQQLIZWRYTPTCIXOHRAFRXXFNBMJNORZISVXSBVDDAVQCUGKMHIFXPYTSKXHMNEJBPLKMZWGWWCRBGDTUCXGGMBSUCFHENRQWMPMIWYMLBJBNGRMHDNKPYCPNTQKUOCIFLVPRRLYDLUEDAENKTAAAGAXJAYPFNRWZAWCLCUPRPGEDYMNOCZBOBIYKXFRSWSPTYECECCIYKILZWULOLACOPIYSXRNXDWVWQKFTJJMARDDSWZODTCHVPBDPGJGKOKUNMOILOSECOCWMEFVXDJEAPAGPHQMZCCLGIPFIQDPAYFGNERKBOIGFGTYMHTEYGEALQPDOZNHAUDCKTTKPFKLTVGAORTAXZQTTFVXONVBBBGLDROSOIOTVTGQKPOXGMJADJIEYWWBJJKRPVXXDALPKXXZYENZZYVOSFHTIJTSMNJMJPBOSRTFBTQGLJGTJWCKNWYJNEOTHTDXNLQIDYGHEQMYPBHZDAJPKYZNRRBOCZYHQTSASXPKQUFWJZUMWPQGKNMOLDRMXRFFSFIWJGGFKYYPTDERWORNJRXCGDPPFDNYPADDRYDQIKWLPXVIYAPIARWBHFPFRRAHLAASZAAYLBEYVMNJHGQFNEYXECWLIXYRKPAOWDJYARWYNXGVRGYLAVTGBCNWDOPODNNGMYMEXSEWHAKGWATBZNQOVTMUPMULBIVAJAJSUUOIQWYBSGADUNOPWZKSMROKXSVZEKWVRAHFZIYZUKCJMRQNTFDKPQGCFDLXAZXHJELUGJQOALXBPEYFBIFZGLGATEZVXAYVNUZHFWHJPPKESFNBFFVSTXBYYKABKUQAMCNUFQAFBVJRBBIORYQSEFBQTBJVWFZVYJRQSSVPEQRXNJWWCMJMEYVHAWBEHFIVWOSRJRVZCANNODCJEMSKVNRAOKQVRQHZIVBZREMLQKJDLHSWURZUMYZIXRDZBZHLTNFSCDRAZGTKDNPGRTBZRNNKVTBAANKQCXKXBAURZYVGEOEJCWIHYIUG0883060481321616939762225691116711921463933029246625305766737827451979557673819545458140516462500667826717863284619147820036308506224272974127633184346373678030835605934726279230222416985150383329203714061009343871841971087334395003750735597571651158822162662761433901010537351678213717059807383603864014828570109444772595220225474780320988957870883883127979350300632812488363735043169055244063754723707039586414431614058756832450801124602957983962214076504129702550220600100076387924573561958214433274150396642773288897775975288554301276428681827403663550828410719737290237908405878598185144890897208920242564132354212065215534711019784824662090254567524270570875301356939740311438015359441435478778899762888495803186995281550326264354925257105652129277360710245112155925073807590710709698311500198249720319356222043541346661446360924109038923209856755690205897308539894450341336159051523389314052476006239435996973734701540404628986914372109848233032766546572580691005845169279117059611947870061824723819660627635543098906`
- 1000 instances of the following template generated in 3 milliseconds.
  - `\\WBQNDYVINMKYKGJAYNBHDZDKLMFWUFQVESZDGELDWYFFZQDEYB`
- 1000 instances of the following template generated in 3 milliseconds.
  - `\\JXULXXFBRSYOHWOURHFUTBXKFTXLUIBYTEHYJGBFBDUKYKXJKW`

 This README was generated using the generator.  See the unit tests for other examples.
